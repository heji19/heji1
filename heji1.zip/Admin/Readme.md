 
**Admin Login Details**
Email : admin@mail.com
Password: Password@123

**Teacher Login Details** 
Email : teacher@mail.com
Password: pass123

